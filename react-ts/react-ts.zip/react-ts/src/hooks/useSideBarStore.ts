import { useQuery, useQueryClient } from '@tanstack/react-query';

export function useSideBarStore() {
	const queryClient = useQueryClient();
	const { data: expanded } = useQuery({
		queryKey: ['expanded'],
		staleTime: Infinity,
		initialData: true,
	});
	const setExpanded = (expanded: boolean) => {
		queryClient.setQueriesData(['expanded'], expanded);
	};
	return { expanded, setExpanded };
}
