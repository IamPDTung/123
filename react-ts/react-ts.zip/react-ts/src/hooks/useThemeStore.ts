import { useQuery, useQueryClient } from '@tanstack/react-query';

export function useThemeStore() {
	const queryClient = useQueryClient();
	const { data: theme } = useQuery({
		queryKey: ['theme'],
		staleTime: Infinity,
		initialData: localStorage.getItem('theme') || 'light',
	});
	const setTheme = (theme: string) => {
		queryClient.setQueriesData(['theme'], theme);
	};
	return { theme, setTheme };
}
