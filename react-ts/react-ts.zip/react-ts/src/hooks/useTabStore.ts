import { useQuery, useQueryClient } from '@tanstack/react-query';
import { DepthMenu } from '../modules/home/types';

export function useTabStore() {
	const queryClient = useQueryClient();
	const { data: tab } = useQuery<DepthMenu | null>({
		queryKey: ['tab'],
		staleTime: Infinity,
		initialData: null,
	});
	const setTab = (tab: DepthMenu) => {
		queryClient.setQueriesData(['tab'], tab);
	};
	return { tab, setTab };
}
