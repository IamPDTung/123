import React from 'react';

interface IAvatarProps {
	src: string;
	name?: string;
	size?: string;
}

function handleName(name: string | undefined) {
	if (!name || typeof name !== 'string') {
		return ''; // Return empty string for invalid input
	}

	const names = name.trim().split(/\s+/); // Trim and split by spaces
	if (names.length === 0) {
		return ''; // Return empty string if no names found
	}

	const firstInitial = names[0].charAt(0).toUpperCase(); // Get first name's initial

	if (names.length > 1) {
		const lastInitial = names[names.length - 1].charAt(0).toUpperCase(); // Get last name's initial
		return firstInitial + lastInitial;
	} else {
		//if only one name is provided, return only the first initial.
		return firstInitial;
	}
}

const Avatar = ({ src, name, size = 'w-12 h-12' }: IAvatarProps) => {
	const [error, setError] = React.useState(false);

	const handleImageError = () => {
		setError(true);
	};

	return (
		<div className={`relative ${size} p-2`}>
			{error ? (
				<span className='w-full h-full bg-black rounded-full text-white flex justify-center items-center'>
					{handleName(name)}
				</span>
			) : (
				<img src={src} alt={name} className='rounded-full w-full h-full object-cover' onError={handleImageError} />
			)}
		</div>
	);
};

export default Avatar;
