import { FunctionComponent, ReactNode } from 'react';
import { useThemeStore } from '../../hooks/useThemeStore';

interface IconProps {
	icon: ReactNode;
}

const Icon: FunctionComponent<IconProps> = ({ icon }) => {
	const { theme } = useThemeStore();

	return (
		<button key={theme} style={{ color: theme === 'light' ? '#5B5C5B' : 'fff' }}>
			{icon}
		</button>
	);
};

export default Icon;
