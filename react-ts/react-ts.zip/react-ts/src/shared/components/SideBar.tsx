import { ReactNode, useState } from 'react';
import { useSideBarStore } from '../../hooks/useSideBarStore';
import { useTabStore } from '../../hooks/useTabStore';
import SidebarItem from './SideBarItem';

interface ISideBar {
	children?: ReactNode;
}

function Sidebar({ children }: ISideBar) {
	const { expanded, setExpanded } = useSideBarStore();
	const { tab } = useTabStore();

	return (
		<div className='relative'>
			<div className={`fixed inset-0 -z-10 block bg-gray-400  ${expanded ? 'block sm:hidden' : 'hidden'}`} />
			<aside
				className={`box-border border-menu-not-active/30 h-[calc(100vh-44px)] transition-all border-none overflow-hidden ${
					expanded ? 'w-5/6 sm:w-1/4' : 'w-0'
				}`}
			>
				<nav className='flex h-full flex-col border-r-2 border-menu-not-active/30 bg-white shadow-sm'>
					<h1 className='border-b-2 border-menu-not-active/30 p-4'>{tab?.title}</h1>
					<ul className='flex-1 px-3'>{children}</ul>
				</nav>
			</aside>
		</div>
	);
}

export default function MakeSidebar() {
	const { tab } = useTabStore();
	const { expanded } = useSideBarStore();

	const navBarItems = tab?.menu;
	console.log('🚀 ~ navBarItems:', navBarItems);

	// Desktop Sidebar
	return (
		<Sidebar>
			{navBarItems && navBarItems.map((item, index) => <SidebarItem key={index} expanded={expanded} {...item} />)}
		</Sidebar>
	);
}
