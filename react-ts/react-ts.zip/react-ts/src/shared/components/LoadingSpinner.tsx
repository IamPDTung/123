interface ILoadingSpinner {
	size?: string;
	color?: string;
}
const LoadingSpinner = ({ size = 'w-6 h-6', color = 'border-primary' }: ILoadingSpinner) => {
	return (
		<span className={`inline-block border-2 rounded-full border-t-transparent animate-spin ${size} ${color}`}></span>
	);
};

export default LoadingSpinner;
