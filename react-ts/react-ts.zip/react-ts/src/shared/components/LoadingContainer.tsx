import { FunctionComponent, ReactNode } from 'react';
import LoadingSpinner from './LoadingSpinner';

interface LoadingContainerProps {
	children: ReactNode;
	isLoading: boolean;
}

const LoadingContainer: FunctionComponent<LoadingContainerProps> = ({ children, isLoading }) => {
	return (
		<>
			{isLoading ? (
				<span className='flex h-full w-full justify-center items-center'>
					<LoadingSpinner />
				</span>
			) : (
				children
			)}
		</>
	);
};

export default LoadingContainer;
