import { useEffect } from 'react';
import { useThemeStore } from '../../hooks/useThemeStore';
import { twMerge } from 'tailwind-merge';
import { Moon, SunDim } from 'lucide-react';

function ToggleTheme() {
	const { theme, setTheme } = useThemeStore();

	useEffect(() => {
		localStorage.setItem('theme', theme);
		document.documentElement.classList.toggle('dark', theme === 'dark');
	}, [theme]);

	const toggleTheme = () => {
		setTheme(theme === 'light' ? 'dark' : 'light');
	};

	return (
		<>
			<div className='relative inline-flex items-center' onClick={toggleTheme}>
				<input type='checkbox' id='toggle' className='sr-only peer' />
				<label
					htmlFor='toggle'
					className='block w-16 h-8 bg-[#EAEEED] rounded-full cursor-pointer peer-checked:bg-[#EAEEED] border border-gray-200 shadow'
				>
					{theme === 'dark' && <SunDim className='absolute top-1 left-2 w-6 h-6' />}
					<span
						className={twMerge(
							'absolute top-1 w-6 h-6 bg-white rounded-full transition-transform duration-300 transform flex items-center justify-center shadow',
							theme === 'light' ? 'left-1' : 'right-1',
						)}
					></span>
					{theme === 'light' && <Moon className='absolute top-1 right-2 w-6 h-6' />}
				</label>
			</div>
		</>
	);
}

export default ToggleTheme;
