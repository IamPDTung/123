import { AlignJustify, CircleHelp, Settings, Star } from 'lucide-react';
import Logo from '../../assets/ESN';
import Tabs from './Tabs';
import ToggleTheme from '../components/ToggleTheme';
import Icon from '../components/Icon';
import Avatar from '../components/Avatar';
import { useMenu } from '../../modules/home/queries/useMenuQuery';
import LoadingContainer from '../components/LoadingContainer';
import { useSideBarStore } from '../../hooks/useSideBarStore';

interface IProps {}

const Navbar = (props: IProps) => {
	const { data, isLoading } = useMenu();
	const { expanded, setExpanded } = useSideBarStore();

	return (
		<div className='bg-menu-bg flex justify-between border-b-2 border-menu-not-active/30'>
			<section className='flex gap-4 items-center'>
				<span className='bg-primary h-12 w-12 flex justify-center items-center' onClick={() => setExpanded(!expanded)}>
					<AlignJustify color='white' />
				</span>
				<Logo />
				<span className='w-0.5 bg-gray-300 h-8' />
				<span>
					<span className='block font-bold text-primary text-xs'>한글시스템명</span>
					<span className='text-gray-400 text-xs'>English System Name</span>
				</span>
			</section>
			<section>
				<LoadingContainer isLoading={isLoading}>
					<Tabs tabs={data} />
				</LoadingContainer>
			</section>
			<section className='flex items-center gap-2 mr-4'>
				<Icon icon={<Star />} />
				<Icon icon={<CircleHelp />} />
				<Icon icon={<Settings />} />
				<ToggleTheme />
				<Avatar src='https://avatars.githubusercontent.com/u/124599?v=4' name='Tommy Phung' />
				<span>홍길동</span>
			</section>
		</div>
	);
};

export { Navbar };
