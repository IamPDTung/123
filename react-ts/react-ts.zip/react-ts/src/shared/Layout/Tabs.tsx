import { FunctionComponent } from 'react';
import { twMerge } from 'tailwind-merge';
import { useTabStore } from '../../hooks/useTabStore';
import { DepthMenu } from '../../modules/home/types';
import React from 'react';

interface TabsProps {
	tabs: DepthMenu[];
}

const Tabs: FunctionComponent<TabsProps> = ({ tabs }) => {
	const { tab, setTab } = useTabStore();

	React.useEffect(() => {
		if (!tab) {
			setTab(tabs[0]);
		}
	}, [tabs]);

	return (
		<section className='h-full flex gap-4'>
			{tabs?.map((item) => (
				<button
					key={item.id}
					onClick={() => setTab(item)}
					className={twMerge(
						'h-full flex items-center font-medium text-menu-not-active hover:cursor-pointer',
						tab?.id === item.id && 'border-b-2 border-primary text-black',
					)}
				>
					{item.title}
				</button>
			))}
		</section>
	);
};

export default Tabs;
