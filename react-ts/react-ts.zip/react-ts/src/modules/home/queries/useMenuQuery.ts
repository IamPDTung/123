import { useQuery } from '../../../utils';
import { mockApiCall } from '../../../utils/fetchData';
import { menu } from '../mocks/menu';
import { DepthMenu } from '../types';

export function useMenu() {
	return useQuery({
		queryKey: ['menu'],
		queryFn: async (): Promise<Array<DepthMenu>> => {
			return await mockApiCall(200, menu);
		},
	});
}
