export const menu = [
	{
		id: 1,
		title: 'Depth Menu 1',
		menu: [
			{
				id: 1,
				title: 'MenuText 1 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 1-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 2,
				title: 'MenuText 2 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 2-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 3,
				title: 'MenuText 3 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 3-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 4,
				title: 'MenuText 4 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 4-1 ',
						subMenu: [],
					},
				],
			},
		],
	},
	{
		id: 2,
		title: 'Depth Menu 2',
		menu: [
			{
				id: 1,
				title: 'MenuText 1 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 1-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 2,
				title: 'MenuText 2 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 2-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 3,
				title: 'MenuText 3 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 3-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 4,
				title: 'MenuText 4 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 4-1 ',
						subMenu: [],
					},
				],
			},
		],
	},
	{
		id: 3,
		title: 'Depth Menu 3',
		menu: [
			{
				id: 1,
				title: 'MenuText 1 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 1-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 2,
				title: 'MenuText 2 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 2-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 3,
				title: 'MenuText 3 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 3-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 4,
				title: 'MenuText 4 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 4-1 ',
						subMenu: [],
					},
				],
			},
		],
	},
	{
		id: 4,
		title: 'Depth Menu 4',
		menu: [
			{
				id: 1,
				title: 'MenuText 1 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 1-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 2,
				title: 'MenuText 2 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 2-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 3,
				title: 'MenuText 3 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 3-1 ',
						subMenu: [],
					},
				],
			},
			{
				id: 4,
				title: 'MenuText 4 ',
				subMenu: [
					{
						id: 1,
						title: 'MenuText 4-1 ',
						subMenu: [],
					},
				],
			},
		],
	},
];
