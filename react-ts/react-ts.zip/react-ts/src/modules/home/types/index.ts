export type DepthMenu = {
	id: number;
	title: string;
	menu: MenuItem[];
};

export type MenuItem = {
	id: number;
	title: string;
	subMenu: MenuItem[];
};
