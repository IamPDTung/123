interface IProps {}

const ProductPage  = ({}: IProps) => {
  return <>ProductPage </>;
};

export { ProductPage  };
