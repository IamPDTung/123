import MakeSidebar from '../../shared/components/SideBar';
import { Navbar } from '../../shared/Layout';

interface IProps {}

const HomePage = ({}: IProps) => {
	return (
		<div className='flex flex-col'>
			<Navbar />
			<section className=' grow'>
				<MakeSidebar />
			</section>
		</div>
	);
};

export { HomePage };
