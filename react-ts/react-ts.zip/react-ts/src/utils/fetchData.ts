async function fetchJson(url: string) {
	try {
		const response = await fetch(url);

		if (!response.ok) {
			throw new Error(`HTTP error! status: ${response.status}`);
		}

		const jsonData = await response.json();
		return jsonData; // Return the parsed JSON data
	} catch (error) {
		console.error('Error fetching or parsing JSON:', error);
		return null; // Or handle the error as needed (e.g., throw it)
	}
}

export const mockApiCall = (delay: number, data: any): any => {
	return new Promise((resolve) => {
		setTimeout(() => {
			resolve(data);
		}, delay);
	});
};

export { fetchJson };
